#pragma once

#include "common.hpp"

POLYBAR_NS

namespace cairo {
  class context;
  class surface;
  class xcb_surface;
  class font;
  class font_fc;
}

POLYBAR_NS_END
